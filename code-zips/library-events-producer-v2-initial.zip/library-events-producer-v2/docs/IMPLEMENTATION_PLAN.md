# Implementation Plan
## Library Events Producer API v2

- **Reference:** `docs/PRD.md`
- **Tech Stack:** Spring Boot 4, Java 25, Gradle, Kafka
- **Configuration Style:** `application.yml` (primary)

## 1) Delivery Strategy
Build the application layer by layer so each step is testable and releasable. Keep controller thin, business rules centralized in service, and Kafka concerns isolated in producer/config layers.

## 2) Layered Plan and Milestones

### Layer 0 - Project Foundation
**Goal:** Prepare dependencies, package layout, and YAML-based configuration.

**Tasks**
- Validate/update `build.gradle` dependencies:
  - `spring-boot-starter-web`
  - `spring-kafka`
  - `spring-boot-starter-actuator`
  - `org.springframework.boot:spring-boot-starter-validation`
  - `com.fasterxml.jackson.core:jackson-databind:2.20.2` (Kafka `JsonSerializer` runtime compatibility)
  - Ensure Jackson alignment note is documented in code comments/PR: this version must align with `jackson-annotations:2.20` constrained by the Jackson 3.x BOM.
  - test dependencies including `spring-kafka-test`
- Keep one config source: `src/main/resources/application.yml`.
- Create package structure under `com.learnjava`:
  - `controller`, `domain`, `service`, `producer`, `config`, `exception`
- Add app constants for API base path and defaults where useful.

**Deliverables**
- App boots with no custom logic errors.
- `application.yml` in place and loaded.

**Exit Criteria**
- `./gradlew test` passes with baseline context test.

---

### Layer 1 - Domain Model + Validation
**Goal:** Implement core request/event models and validation constraints.

**Tasks**
- Create `Book` model:
  - `bookId` (required)
  - `bookName` (required, non-blank)
  - `bookAuthor` (required, non-blank)
- Create `LibraryEvent` model:
  - `libraryEventId`
  - `eventType` (`ADD`, `UPDATE`)
  - `book` (required)
- Create enum `LibraryEventType` with values `ADD`, `UPDATE`.
- Add Jakarta Bean Validation annotations.

**Deliverables**
- Domain classes with validation metadata.

**Exit Criteria**
- Unit tests validate happy path and missing-field failures.

---

### Layer 2 - API Layer (Controller)
**Goal:** Expose PRD endpoints and return full payload on success.

**Tasks**
- Implement `LibraryEventsController` endpoints:
  - `POST /v1/library-events`
  - `PUT /v1/library-events`
- Validate request body using `@Valid`.
- Enforce method-specific event type behavior:
  - `POST` requires `ADD`
  - `PUT` requires `UPDATE`
- Return:
  - `201 Created` with full payload for POST
  - `200 OK` with full payload for PUT

**Deliverables**
- REST endpoints wired to service layer.

**Exit Criteria**
- Controller tests cover success and invalid-request scenarios.

---

### Layer 3 - Service Layer (Business Rules)
**Goal:** Centralize business validation and orchestration.

**Tasks**
- Create `LibraryEventService` and implementation.
- Methods:
  - `createLibraryEvent(LibraryEvent event)`
  - `updateLibraryEvent(LibraryEvent event)`
- Enforce rules:
  - POST flow must be `ADD`
  - PUT flow must be `UPDATE`
  - PUT requires non-null `libraryEventId`
- Delegate Kafka publish to producer component.

**Deliverables**
- Service abstraction and implementation with rule checks.

**Exit Criteria**
- Service unit tests cover rule enforcement and delegation behavior.

---

### Layer 4 - Kafka Producer Layer
**Goal:** Publish valid events to Kafka topic using YAML-configured properties.

**Tasks**
- Create `LibraryEventProducer` using `KafkaTemplate<Long, LibraryEvent>`.
- Read topic from YAML (`app.kafka.topic`).
- Publish with key = `libraryEventId`.
- Add publish result logging (success/failure).
- Wrap/propagate failures as domain-specific exception.

**Deliverables**
- Producer class + YAML-backed topic config.

**Exit Criteria**
- Producer tests verify topic/key/payload usage and error path.

---

### Layer 5 - Exception Handling + Error Contract
**Goal:** Standardize API error responses as per PRD.

**Tasks**
- Add custom exceptions:
  - `InvalidLibraryEventException`
  - `LibraryEventPublishException`
- Implement `@RestControllerAdvice`:
  - `400` for validation/business mismatch errors
  - `500` for publish/internal errors
- Use common error response model:
  - timestamp, status, message, path, optional traceId

**Deliverables**
- Global exception handler and error response schema.

**Exit Criteria**
- Endpoint tests verify expected error status and structure.

---

### Layer 6 - Configuration + Observability (YAML)
**Goal:** Externalize runtime settings and basic operational visibility.

**Tasks**
- Configure in `application.yml`:
  - Kafka bootstrap servers
  - producer retries/backoff
  - topic name (`app.kafka.topic`)
  - actuator endpoint exposure
- Add metrics/logging for request and publish outcomes.
- Keep logs structured with `libraryEventId`, `eventType`, `bookId`.

**Deliverables**
- Runtime-ready YAML config and health/metrics visibility.

**Exit Criteria**
- Health endpoint available and metrics emitted.

---

### Layer 7 - Integration Testing
**Goal:** Validate end-to-end REST-to-Kafka behavior.

**Tasks**
- Add integration tests using embedded Kafka or Testcontainers.
- Verify POST (`ADD`) publishes one message and returns full payload.
- Verify PUT (`UPDATE`) publishes one message and returns full payload.
- Negative tests for:
  - wrong event type by method
  - missing `libraryEventId` on PUT
  - missing `book`/book fields

**Deliverables**
- Reliable integration test suite aligned to acceptance criteria.

**Exit Criteria**
- All PRD acceptance criteria covered by tests.

---

### Layer 8 - Documentation + Release Readiness
**Goal:** Keep design and usage discoverable and release-safe.

**Tasks**
- Add/update API docs (OpenAPI optional in this phase).
- Add request/response examples and error examples.
- Document local run/test instructions in `README.md`.
- Final review against `docs/PRD.md` acceptance criteria.

**Deliverables**
- Updated docs and release checklist.

**Exit Criteria**
- Team can run, test, and validate behavior locally with minimal setup.

## 3) Recommended File-Level Implementation Order
1. `build.gradle`
2. `src/main/resources/application.yml`
3. `src/main/java/com/learnjava/domain/Book.java`
4. `src/main/java/com/learnjava/domain/LibraryEvent.java`
5. `src/main/java/com/learnjava/domain/LibraryEventType.java`
6. `src/main/java/com/learnjava/controller/LibraryEventsController.java`
7. `src/main/java/com/learnjava/service/LibraryEventService.java`
8. `src/main/java/com/learnjava/service/LibraryEventServiceImpl.java`
9. `src/main/java/com/learnjava/producer/LibraryEventProducer.java`
10. `src/main/java/com/learnjava/config/*` (Kafka/topic properties)
11. `src/main/java/com/learnjava/exception/*`
12. `src/test/java/com/learnjava/*` unit + integration tests

## 4) Acceptance Checklist (Mapped to PRD)
- [ ] POST endpoint exists and enforces `eventType=ADD`.
- [ ] PUT endpoint exists and enforces `eventType=UPDATE`.
- [ ] PUT rejects null/missing `libraryEventId`.
- [ ] Book and mandatory fields are validated.
- [ ] Success responses return full event payload.
- [ ] Valid events are published to Kafka topic from YAML config.
- [ ] `400` and `500` error responses follow standardized shape.
- [ ] Unit and integration tests pass.

## 5) Suggested `application.yml` Baseline
```yaml
server:
  port: 8080

spring:
  application:
    name: library-events-producer-v2
  kafka:
    bootstrap-servers: localhost:9092
    producer:
      acks: all
      retries: 10
      key-serializer: org.apache.kafka.common.serialization.LongSerializer
      value-serializer: org.springframework.kafka.support.serializer.JsonSerializer
      properties:
        retry:
          backoff:
            ms: 1000

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics
  endpoint:
    health:
      probes:
        enabled: true

app:
  kafka:
    topic: library-events
```

## 6) Commit Plan
1. `chore: add dependencies and yaml config baseline`
2. `feat: add domain model and validation rules`
3. `feat: add library events controller endpoints`
4. `feat: add service and kafka producer publishing`
5. `feat: add exception handling and error contract`
6. `test: add unit tests for controller and service`
7. `test: add integration tests for kafka publish flow`
8. `docs: align readme and api examples with prd`
