# Payload Validation – cURL Test Commands

---

## Table of Contents

### 📮 POST `/v1/libraryevent`
- [Validation Rules Summary](#validation-rules-summary)
- [✅ 1. Happy Path – Valid ADD Event](#-1-happy-path--valid-add-event)
- [❌ 2. Missing `eventType`](#-2-missing-eventtype)
- [❌ 3. `eventType` Set to `UPDATE` (rejected by controller logic)](#-3-eventtype-set-to-update-rejected-by-controller-logic)
- [❌ 4. Missing `book` Object](#-4-missing-book-object)
- [❌ 5. `book` Explicitly `null`](#-5-book-explicitly-null)
- [❌ 6. Missing `bookId`](#-6-missing-bookid)
- [❌ 7. Missing `bookName`](#-7-missing-bookname)
- [❌ 8. Blank `bookName` (whitespace only)](#-8-blank-bookname-whitespace-only)
- [❌ 9. Missing `bookAuthor`](#-9-missing-bookauthor)
- [❌ 10. Blank `bookAuthor` (empty string)](#-10-blank-bookauthor-empty-string)
- [❌ 11. Multiple Validation Failures at Once](#-11-multiple-validation-failures-at-once)
- [❌ 12. Completely Empty Body](#-12-completely-empty-body)
- [❌ 13. Malformed JSON](#-13-malformed-json)
- [❌ 14. Invalid `eventType` Enum Value](#-14-invalid-eventtype-enum-value)

### 📝 PUT `/v1/libraryevent`
- [Validation Rules Summary](#validation-rules-summary-1)
- [✅ 1. Happy Path – Valid UPDATE Event](#-1-happy-path--valid-update-event)
- [❌ 2. Missing `libraryEventId` (null)](#-2-missing-libraryeventid-null)
- [❌ 3. Missing `eventType`](#-3-missing-eventtype)
- [❌ 4. `eventType` Set to `ADD` (rejected by controller logic)](#-4-eventtype-set-to-add-rejected-by-controller-logic)
- [❌ 5. Missing `book` Object](#-5-missing-book-object)
- [❌ 6. `book` Explicitly `null`](#-6-book-explicitly-null)
- [❌ 7. Missing `bookId`](#-7-missing-bookid)
- [❌ 8. Missing `bookName`](#-8-missing-bookname)
- [❌ 9. Blank `bookName` (whitespace only)](#-9-blank-bookname-whitespace-only)
- [❌ 10. Missing `bookAuthor`](#-10-missing-bookauthor)
- [❌ 11. Blank `bookAuthor` (empty string)](#-11-blank-bookauthor-empty-string)
- [❌ 12. Multiple Validation Failures at Once](#-12-multiple-validation-failures-at-once)
- [❌ 13. Completely Empty Body](#-13-completely-empty-body)
- [❌ 14. Malformed JSON](#-14-malformed-json)
- [❌ 15. Invalid `eventType` Enum Value](#-15-invalid-eventtype-enum-value)

---

**Endpoint:** `POST http://localhost:8080/v1/libraryevent`

---

## Validation Rules Summary

| Field | Constraint | Error triggered when |
|---|---|---|
| `eventType` | `@NotNull` + must be `ADD` | missing, `null`, or set to `UPDATE` |
| `book` | `@NotNull` + `@Valid` (cascades) | missing or `null` |
| `book.bookId` | `@NotNull` | missing or `null` |
| `book.bookName` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |
| `book.bookAuthor` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |

> **Error envelope** – every `400` response shares the same JSON shape:
> ```json
> { "errors": [ "message 1", "message 2" ] }
> ```

---

## ✅ 1. Happy Path – Valid ADD Event

Expected: **201 Created**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "libraryEventId": null,
  "eventType": "ADD",
  "book": {
    "bookId": 1,
    "bookName": "Kafka: The Definitive Guide",
    "bookAuthor": "Neha Narkhede"
  }
}
```

---

## ❌ 2. Missing `eventType`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["eventType is required"]
}
```

---

## ❌ 3. `eventType` Set to `UPDATE` (rejected by controller logic)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["only ADD event type is supported"]
}
```

---

## ❌ 4. Missing `book` Object

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD"
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 5. `book` Explicitly `null`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": null
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 6. Missing `bookId`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookId is required"]
}
```

---

## ❌ 7. Missing `bookName`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 8. Blank `bookName` (whitespace only)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "   ",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 9. Missing `bookAuthor`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 10. Blank `bookAuthor` (empty string)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 11. Multiple Validation Failures at Once

Expected: **400 Bad Request** – all three field errors returned together (sorted alphabetically)

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": null,
      "bookName": "",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": [
    "bookAuthor is required",
    "bookId is required",
    "bookName is required"
  ]
}
```

---

## ❌ 12. Completely Empty Body

Expected: **400 Bad Request** – both top-level fields missing

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{}' | jq .
```

**Response body:**
```json
{
  "errors": [
    "book is required",
    "eventType is required"
  ]
}
```

---

## ❌ 13. Malformed JSON

Expected: **400 Bad Request** – JSON parse error

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{ "eventType": "ADD", "book": { INVALID }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Unexpected token (START_OBJECT), expected..."]
}
```

---

## ❌ 14. Invalid `eventType` Enum Value

Expected: **400 Bad Request** – unknown enum constant

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "DELETE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Cannot deserialize value of type `com.learnjava.domain.LibraryEventType` from String \"DELETE\": not one of the values accepted for Enum class: [ADD, UPDATE]"]
}
```

---

> **Note:** `jq` is used to pretty-print the JSON response. Remove `| jq .` if `jq` is not installed.  
> The server defaults to port **8080**. Adjust if your `server.port` is configured differently.
> Error messages are sorted alphabetically when multiple violations occur simultaneously.

---

# PUT `/v1/libraryevent` – Update Endpoint Validation Tests

**Endpoint:** `PUT http://localhost:8080/v1/libraryevent`

---

## Validation Rules Summary

| Field | Constraint | Error triggered when |
|---|---|---|
| `libraryEventId` | Must be non-null | missing or `null` |
| `eventType` | `@NotNull` + must be `UPDATE` | missing, `null`, or set to `ADD` |
| `book` | `@NotNull` + `@Valid` (cascades) | missing or `null` |
| `book.bookId` | `@NotNull` | missing or `null` |
| `book.bookName` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |
| `book.bookAuthor` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |

> **Error envelope** – every `400` response shares the same JSON shape:
> ```json
> { "errors": [ "message 1", "message 2" ] }
> ```

---

## ✅ 1. Happy Path – Valid UPDATE Event

Expected: **200 OK**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide 2nd Edition",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "libraryEventId": 1,
  "eventType": "UPDATE",
  "book": {
    "bookId": 1,
    "bookName": "Kafka: The Definitive Guide 2nd Edition",
    "bookAuthor": "Neha Narkhede"
  }
}
```

---

## ❌ 2. Missing `libraryEventId` (null)

Expected: **400 Bad Request** – controller guard rejects the request before reaching Kafka

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["libraryEventId is required for UPDATE"]
}
```

---

## ❌ 3. Missing `eventType`

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["eventType is required"]
}
```

---

## ❌ 4. `eventType` Set to `ADD` (rejected by controller logic)

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["only UPDATE event type is supported"]
}
```

---

## ❌ 5. Missing `book` Object

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE"
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 6. `book` Explicitly `null`

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": null
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 7. Missing `bookId`

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookId is required"]
}
```

---

## ❌ 8. Missing `bookName`

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 9. Blank `bookName` (whitespace only)

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "   ",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 10. Missing `bookAuthor`

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 11. Blank `bookAuthor` (empty string)

Expected: **400 Bad Request**

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 12. Multiple Validation Failures at Once

Expected: **400 Bad Request** – all field errors returned together (sorted alphabetically)

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": null,
      "bookName": "",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": [
    "bookAuthor is required",
    "bookId is required",
    "bookName is required"
  ]
}
```

---

## ❌ 13. Completely Empty Body

Expected: **400 Bad Request** – both top-level required fields missing

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{}' | jq .
```

**Response body:**
```json
{
  "errors": [
    "book is required",
    "eventType is required"
  ]
}
```

> **Note:** `libraryEventId` has no `@NotNull` constraint on the domain record itself —
> it is enforced by a dedicated controller guard that fires *after* `@Valid` passes.
> An empty body triggers the Bean Validation failure for `eventType` and `book` first.

---

## ❌ 14. Malformed JSON

Expected: **400 Bad Request** – JSON parse error

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{ "eventType": "UPDATE", "book": { INVALID }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Unexpected token (START_OBJECT), expected..."]
}
```

---

## ❌ 15. Invalid `eventType` Enum Value

Expected: **400 Bad Request** – unknown enum constant

```bash
curl -s -X PUT http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "DELETE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Cannot deserialize value of type `com.learnjava.domain.LibraryEventType` from String \"DELETE\": not one of the values accepted for Enum class: [ADD, UPDATE]"]
}
```

---

> **Note:** `jq` is used to pretty-print the JSON response. Remove `| jq .` if `jq` is not installed.  
> The server defaults to port **8080**. Adjust if your `server.port` is configured differently.
> Error messages are sorted alphabetically when multiple violations occur simultaneously.



