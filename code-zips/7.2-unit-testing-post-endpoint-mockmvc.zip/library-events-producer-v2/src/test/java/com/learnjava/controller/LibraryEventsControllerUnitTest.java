package com.learnjava.controller;

import com.learnjava.service.LibraryEventService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.concurrent.CompletableFuture;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.asyncDispatch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = LibraryEventsController.class)
@Import(LibraryEventsControllerAdvice.class)
class LibraryEventsControllerUnitTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private LibraryEventService libraryEventService;

    @Test
    void postLibraryEvent_returns201_whenEventTypeAdd() throws Exception {
        String requestBody = """
                {
                  "eventType": "ADD",
                  "book": {
                    "bookId": 123,
                    "bookName": "Kafka Using Spring Boot",
                    "bookAuthor": "Dilip"
                  }
                }
                """;

        when(libraryEventService.createLibraryEvent(any()))
                .thenAnswer(invocation -> CompletableFuture.completedFuture(invocation.getArgument(0)));

        MvcResult mvcResult = mockMvc.perform(post("/v1/libraryevent")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.eventType").value("ADD"))
                .andExpect(jsonPath("$.book.bookId").value(123))
                .andExpect(jsonPath("$.book.bookName").value("Kafka Using Spring Boot"))
                .andExpect(jsonPath("$.book.bookAuthor").value("Dilip"));
    }

    @Test
    void postLibraryEvent_returns400_whenEventTypeIsNotAdd() throws Exception {
        String requestBody = """
                {
                  "eventType": "UPDATE",
                  "book": {
                    "bookId": 123,
                    "bookName": "Kafka Using Spring Boot",
                    "bookAuthor": "Dilip"
                  }
                }
                """;

        MvcResult mvcResult = mockMvc.perform(post("/v1/libraryevent")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(request().asyncStarted())
                .andReturn();

        mockMvc.perform(asyncDispatch(mvcResult))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors[0]").value("only ADD event type is supported"));

        verifyNoInteractions(libraryEventService);
    }

    @Test
    void postLibraryEvent_returns400_withValidationErrorsEnvelope_whenRequestBodyInvalid() throws Exception {
        String requestBody = """
                {
                  "eventType": "ADD",
                  "book": {
                    "bookName": "",
                    "bookAuthor": ""
                  }
                }
                """;

        mockMvc.perform(post("/v1/libraryevent")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors").isArray())
                .andExpect(jsonPath("$.errors[0]").value("bookAuthor is required"))
                .andExpect(jsonPath("$.errors[1]").value("bookId is required"))
                .andExpect(jsonPath("$.errors[2]").value("bookName is required"));

        verifyNoInteractions(libraryEventService);
    }

    @Test
    void postLibraryEvent_returns400_withAdviceEnvelope_whenRequestBodyMalformed() throws Exception {
        String requestBody = """
                {
                  "eventType": "DELETE",
                  "book": {
                    "bookId": 123,
                    "bookName": "Kafka Using Spring Boot",
                    "bookAuthor": "Dilip"
                  }
                }
                """;

        mockMvc.perform(post("/v1/libraryevent")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.errors").isArray())
                .andExpect(jsonPath("$.errors[0]").value(org.hamcrest.Matchers.startsWith("Invalid request body:")));

        verifyNoInteractions(libraryEventService);
    }
}




