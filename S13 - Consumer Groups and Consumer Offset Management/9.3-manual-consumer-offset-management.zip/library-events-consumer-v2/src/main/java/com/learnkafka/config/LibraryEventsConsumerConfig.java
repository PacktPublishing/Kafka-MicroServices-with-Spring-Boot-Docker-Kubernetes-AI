package com.learnkafka.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learnkafka.domain.LibraryEventDTO;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;

@Configuration
@EnableKafka
public class LibraryEventsConsumerConfig {

	@Bean
	ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	@Bean
	ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO> kafkaListenerContainerFactory(
			ConsumerFactory<Integer, LibraryEventDTO> consumerFactory) {
		var factory = new ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO>();
		factory.setConsumerFactory(consumerFactory);
		//factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL); // Default ContainerProperties.AckMode.BATCH
		return factory;
	}
}


