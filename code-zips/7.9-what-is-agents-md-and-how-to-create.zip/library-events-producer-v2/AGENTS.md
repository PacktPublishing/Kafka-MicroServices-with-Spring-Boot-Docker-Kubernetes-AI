# AGENTS.md

## Project mission
- This service is a **REST-to-Kafka producer** for library events; no DB writes and no consumer logic (`docs/PRD.md`).
- API semantics are method-bound: `POST` must publish `ADD`, `PUT` must publish `UPDATE`.

## Architecture and data flow
- Entry point: `LibraryEventsController` (`src/main/java/com/learnjava/controller/LibraryEventsController.java`).
- Flow is `Controller -> Service -> Producer -> KafkaTemplate`:
  - Controller applies request validation (`@Valid`) and method-specific guards (`eventType`, `libraryEventId` for PUT).
  - Service is thin and async; it maps producer completion to the original payload and wraps failures in `LibraryEventPublishException`.
  - Producer sends to Kafka topic from `spring.kafka.topic` and logs publish metadata.
- All controller methods return `CompletableFuture<ResponseEntity<?>>`; tests must use async dispatch.

## Domain and validation conventions
- Domain models are Java records (`Book`, `LibraryEvent`) with Bean Validation annotations (`@NotNull`, `@NotBlank`, `@Valid`).
- `libraryEventId` is intentionally **not** `@NotNull` on the record; PUT-only requirement is enforced in controller guard.
- Error envelope is always `{ "errors": ["..."] }` via `LibraryEventsControllerAdvice`.
- Validation messages are sorted alphabetically in advice for deterministic assertions.

## Config and environment
- Primary config is `src/main/resources/application.yml`; active profile defaults to `dev`.
- Kafka broker/topic are profile-specific in `application-dev.yml`, `application-stage.yml`, `application-prod.yml`.
- API base path constant is `AppConstants.API_BASE_PATH` (`/v1/libraryevent`); reuse this constant in tests.
- OpenAPI runtime config lives in `OpenApiConfig`; static spec/examples are in `docs/openapi.yaml`.

## Local workflows
- Start local Kafka cluster (3 brokers) from project root:
```bash
cd /System/Volumes/Data/Dilip/udemy/udemy-recording-folder/kafka-for-developers-using-springboot-v2/library-events-producer-v2
docker compose up -d
```
- Run app/tests with Gradle wrapper:
```bash
./gradlew bootRun
./gradlew test
```
- Manual API verification examples are maintained in `docs/CURL_VALIDATION_TESTS.md`.
- Swagger/OpenAPI runtime docs are available at `http://localhost:8080/swagger-ui.html` (interactive testing) and `http://localhost:8080/v3/api-docs` (raw spec).

## Testing patterns to follow
- Controller unit tests use `@WebMvcTest` + `@MockitoBean` service + `asyncDispatch(...)` (`src/test/java/com/learnjava/controller/LibraryEventsControllerUnitTest.java`).
- Integration tests use `@SpringBootTest` + `@EmbeddedKafka` and consume published records directly (`src/test/java/com/learnjava/controller/LibraryEventsControllerIntegrationTest.java`).
- Producer tests set injected `topic` with `ReflectionTestUtils` and validate both async and synchronous send paths (`src/test/java/com/learnjava/producer/LibraryEventProducerTest.java`).

## Change guardrails for agents
- Keep controller business-rule checks and advice error shape/messages stable; tests assert exact strings.
- If changing endpoint paths or payload contracts, update both `AppConstants` and `docs/openapi.yaml` + controller tests.
- If switching serializer mode in producer (JsonSerializer vs StringSerializer), update both producer code toggles and Kafka serializer config in YAML.
- Prefer adding behavior in service/producer without introducing persistence or consumer-side concerns in this repo.
