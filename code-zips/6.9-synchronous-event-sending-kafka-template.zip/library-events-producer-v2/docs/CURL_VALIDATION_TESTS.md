# Payload Validation – cURL Test Commands

**Endpoint:** `POST http://localhost:8080/v1/libraryevent`

---

## Validation Rules Summary

| Field | Constraint | Error triggered when |
|---|---|---|
| `eventType` | `@NotNull` + must be `ADD` | missing, `null`, or set to `UPDATE` |
| `book` | `@NotNull` + `@Valid` (cascades) | missing or `null` |
| `book.bookId` | `@NotNull` | missing or `null` |
| `book.bookName` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |
| `book.bookAuthor` | `@NotBlank` | missing, `null`, empty `""`, or blank `"  "` |

> **Error envelope** – every `400` response shares the same JSON shape:
> ```json
> { "errors": [ "message 1", "message 2" ] }
> ```

---

## ✅ 1. Happy Path – Valid ADD Event

Expected: **201 Created**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "libraryEventId": null,
  "eventType": "ADD",
  "book": {
    "bookId": 1,
    "bookName": "Kafka: The Definitive Guide",
    "bookAuthor": "Neha Narkhede"
  }
}
```

---

## ❌ 2. Missing `eventType`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["eventType is required"]
}
```

---

## ❌ 3. `eventType` Set to `UPDATE` (rejected by controller logic)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": 1,
    "eventType": "UPDATE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["only ADD event type is supported"]
}
```

---

## ❌ 4. Missing `book` Object

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD"
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 5. `book` Explicitly `null`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": null
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["book is required"]
}
```

---

## ❌ 6. Missing `bookId`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookId is required"]
}
```

---

## ❌ 7. Missing `bookName`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 8. Blank `bookName` (whitespace only)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "   ",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookName is required"]
}
```

---

## ❌ 9. Missing `bookAuthor`

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 10. Blank `bookAuthor` (empty string)

Expected: **400 Bad Request**

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["bookAuthor is required"]
}
```

---

## ❌ 11. Multiple Validation Failures at Once

Expected: **400 Bad Request** – all three field errors returned together (sorted alphabetically)

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "ADD",
    "book": {
      "bookId": null,
      "bookName": "",
      "bookAuthor": ""
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": [
    "bookAuthor is required",
    "bookId is required",
    "bookName is required"
  ]
}
```

---

## ❌ 12. Completely Empty Body

Expected: **400 Bad Request** – both top-level fields missing

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{}' | jq .
```

**Response body:**
```json
{
  "errors": [
    "book is required",
    "eventType is required"
  ]
}
```

---

## ❌ 13. Malformed JSON

Expected: **400 Bad Request** – JSON parse error

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{ "eventType": "ADD", "book": { INVALID }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Unexpected token (START_OBJECT), expected..."]
}
```

---

## ❌ 14. Invalid `eventType` Enum Value

Expected: **400 Bad Request** – unknown enum constant

```bash
curl -s -X POST http://localhost:8080/v1/libraryevent \
  -H "Content-Type: application/json" \
  -d '{
    "libraryEventId": null,
    "eventType": "DELETE",
    "book": {
      "bookId": 1,
      "bookName": "Kafka: The Definitive Guide",
      "bookAuthor": "Neha Narkhede"
    }
  }' | jq .
```

**Response body:**
```json
{
  "errors": ["Invalid request body: Cannot deserialize value of type `com.learnjava.domain.LibraryEventType` from String \"DELETE\": not one of the values accepted for Enum class: [ADD, UPDATE]"]
}
```

---

> **Note:** `jq` is used to pretty-print the JSON response. Remove `| jq .` if `jq` is not installed.  
> The server defaults to port **8080**. Adjust if your `server.port` is configured differently.
> Error messages are sorted alphabetically when multiple violations occur simultaneously.
