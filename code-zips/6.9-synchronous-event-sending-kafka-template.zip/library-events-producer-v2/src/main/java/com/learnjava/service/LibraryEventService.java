package com.learnjava.service;

import com.learnjava.domain.LibraryEvent;
import com.learnjava.exception.LibraryEventPublishException;
import com.learnjava.producer.LibraryEventProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

/**
 * Service layer for {@link LibraryEvent} operations.
 *
 * <p>Enforces business rules before delegating to the Kafka producer.
 * Keeps the controller thin: validation (Bean Validation) lives on the
 * controller, while business-rule enforcement lives here.
 */
@Service
public class LibraryEventService {

    private static final Logger log = LoggerFactory.getLogger(LibraryEventService.class);

    private final LibraryEventProducer libraryEventProducer;

    public LibraryEventService(LibraryEventProducer libraryEventProducer) {
        this.libraryEventProducer = libraryEventProducer;
    }

    /**
     * Publishes a new library event to Kafka.
     *
     * <p>The caller (controller) is responsible for enforcing {@code eventType == ADD}
     * before invoking this method.
     *
     * @param libraryEvent the validated event from the controller
     * @return the same event (echoed back so the controller can build the response)
     * @throws LibraryEventPublishException if the Kafka send fails
     */
    public LibraryEvent createLibraryEvent(LibraryEvent libraryEvent) {


        log.debug("Creating library event: libraryEventId={}, bookId={}",
                libraryEvent.libraryEventId(),
                libraryEvent.book() != null ? libraryEvent.book().bookId() : null);

        try {
            // Block until the broker acknowledges the message.
            // Failures surface as ExecutionException wrapping the root cause.
            libraryEventProducer.sendLibraryEvent(libraryEvent).get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new LibraryEventPublishException(
                    "Thread interrupted while publishing library event", e);
        } catch (ExecutionException e) {
            throw new LibraryEventPublishException(
                    "Failed to publish library event to Kafka", e.getCause());
        }

        log.info("LibraryEvent created and published: libraryEventId={}", libraryEvent.libraryEventId());
        return libraryEvent;
    }
}

