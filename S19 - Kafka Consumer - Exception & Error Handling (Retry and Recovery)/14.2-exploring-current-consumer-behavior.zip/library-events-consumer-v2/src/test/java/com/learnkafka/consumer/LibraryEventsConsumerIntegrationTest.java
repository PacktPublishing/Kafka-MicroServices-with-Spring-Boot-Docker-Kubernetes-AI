package com.learnkafka.consumer;

import com.learnkafka.domain.Book;
import com.learnkafka.domain.LibraryEventDTO;
import com.learnkafka.domain.LibraryEventType;
import com.learnkafka.repository.BookRepository;
import com.learnkafka.repository.LibraryEventRepository;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.testcontainers.context.ImportTestcontainers;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.kafka.test.EmbeddedKafkaBroker;
import org.springframework.kafka.test.context.EmbeddedKafka;
import org.springframework.test.context.TestPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.BooleanSupplier;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

@SpringBootTest
@EmbeddedKafka(partitions = 1, topics = {"library-events"},
        bootstrapServersProperty = "spring.kafka.consumer.bootstrap-servers")
@TestPropertySource(properties = {
        "spring.kafka.consumer.auto-offset-reset=earliest"
})
@ImportTestcontainers
class LibraryEventsConsumerIntegrationTest {

    @ServiceConnection
    static PostgreSQLContainer<?> postgres = new PostgreSQLContainer<>("postgres:latest");

    @Autowired
    private EmbeddedKafkaBroker embeddedKafkaBroker;

    @Autowired
    private LibraryEventRepository libraryEventRepository;

    @Autowired
    private BookRepository bookRepository;

    private KafkaTemplate<Integer, LibraryEventDTO> kafkaTemplate;

    @BeforeEach
    void setUp() {
        bookRepository.deleteAll();
        libraryEventRepository.deleteAll();

        Map<String, Object> producerProps = new HashMap<>();
        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, embeddedKafkaBroker.getBrokersAsString());
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

        var producerFactory = new DefaultKafkaProducerFactory<Integer, LibraryEventDTO>(producerProps);
        kafkaTemplate = new KafkaTemplate<>(producerFactory);
    }

    @Test
    void consumeLibraryEvent_ADD_shouldPersistLibraryEventAndBook() throws Exception {
        Book book = new Book(100L, "Clean Code", "Robert C. Martin");
        LibraryEventDTO dto = new LibraryEventDTO(null, LibraryEventType.ADD, book);

        kafkaTemplate.send("library-events", dto).get(10, TimeUnit.SECONDS);
        waitForRecordCount(1, 10);

        var events = libraryEventRepository.findAll();
        var books = bookRepository.findAll();

        assertEquals(1, events.size());
        assertEquals(1, books.size());

        var savedEvent = events.getFirst();
        var savedBook = books.getFirst();

        assertNotNull(savedEvent.getLibraryEventId());
        assertEquals(LibraryEventType.ADD, savedEvent.getEventType());
        assertNotNull(savedEvent.getCreatedAt());
        assertNotNull(savedEvent.getUpdatedAt());

        assertEquals(100, savedBook.getBookId());
        assertEquals("Clean Code", savedBook.getBookName());
        assertEquals("Robert C. Martin", savedBook.getBookAuthor());
        assertNotNull(savedBook.getLibraryEvent());
        assertEquals(savedEvent.getLibraryEventId(), savedBook.getLibraryEvent().getLibraryEventId());
        assertNotNull(savedBook.getCreatedAt());
        assertNotNull(savedBook.getUpdatedAt());
    }

    @Test
    void consumeLibraryEvent_UPDATE_shouldUpdateExistingLibraryEventAndBook() throws Exception {
        Book addBook = new Book(101L, "Kafka Basics", "Alice");
        LibraryEventDTO addDto = new LibraryEventDTO(null, LibraryEventType.ADD, addBook);
        kafkaTemplate.send("library-events", addDto).get(10, TimeUnit.SECONDS);

        waitForRecordCount(1, 10);
        Integer existingId = libraryEventRepository.findAll().getFirst().getLibraryEventId();

        Book updateBook = new Book(101L, "Kafka in Action", "Bob");
        LibraryEventDTO updateDto = new LibraryEventDTO(existingId.longValue(), LibraryEventType.UPDATE, updateBook);
        kafkaTemplate.send("library-events", updateDto).get(10, TimeUnit.SECONDS);

        waitForCondition(() -> libraryEventRepository.findById(existingId)
                        .map(event -> event.getEventType() == LibraryEventType.UPDATE
                                && event.getBook() != null
                                && "Kafka in Action".equals(event.getBook().getBookName())
                                && "Bob".equals(event.getBook().getBookAuthor()))
                        .orElse(false),
                10,
                "Timed out waiting for UPDATE event to be persisted");

        assertEquals(1, libraryEventRepository.count());
        assertEquals(1, bookRepository.count());
        assertEquals("Kafka in Action", bookRepository.findById(101).orElseThrow().getBookName());
    }

    @Test
    void consumeLibraryEvent_invalid_withNullBook_shouldNotPersistAnyRecord() throws Exception {
        LibraryEventDTO invalidDto = new LibraryEventDTO(null, LibraryEventType.ADD, null);

        kafkaTemplate.send("library-events", invalidDto).get(10, TimeUnit.SECONDS);

        assertConditionRemainsTrue(
                () -> libraryEventRepository.count() == 0 && bookRepository.count() == 0,
                3,
                "Unexpected persistence happened for invalid ADD event with null book");
    }

    @Test
    void consumeLibraryEvent_UPDATE_withNullLibraryEventId_shouldNotUpdateExistingRecord() throws Exception {
        Book addBook = new Book(102L, "Refactoring", "Martin Fowler");
        LibraryEventDTO addDto = new LibraryEventDTO(null, LibraryEventType.ADD, addBook);
        kafkaTemplate.send("library-events", addDto).get(10, TimeUnit.SECONDS);

        waitForRecordCount(1, 10);

        Integer existingId = libraryEventRepository.findAll().getFirst().getLibraryEventId();
        String originalBookName = bookRepository.findById(102).orElseThrow().getBookName();

        Book invalidUpdateBook = new Book(102L, "Refactoring 2nd Edition", "Martin Fowler");
        LibraryEventDTO invalidUpdateDto = new LibraryEventDTO(null, LibraryEventType.UPDATE, invalidUpdateBook);
        kafkaTemplate.send("library-events", invalidUpdateDto).get(10, TimeUnit.SECONDS);

        assertConditionRemainsTrue(
                () -> libraryEventRepository.count() == 1
                        && bookRepository.count() == 1
                        && libraryEventRepository.findById(existingId)
                        .map(event -> event.getEventType() == LibraryEventType.ADD)
                        .orElse(false)
                        && bookRepository.findById(102)
                        .map(book -> originalBookName.equals(book.getBookName()))
                        .orElse(false),
                3,
                "Invalid UPDATE with null libraryEventId unexpectedly changed persisted data");
    }

    private void waitForRecordCount(long expectedCount, int timeoutSeconds) throws InterruptedException {
        waitForCondition(() -> libraryEventRepository.count() >= expectedCount,
                timeoutSeconds,
                "Timed out waiting for " + expectedCount + " record(s), found " + libraryEventRepository.count());
        Thread.sleep(200);
    }

    private void waitForCondition(BooleanSupplier condition,
                                  int timeoutSeconds,
                                  String failureMessage) throws InterruptedException {
        for (int i = 0; i < timeoutSeconds * 10; i++) {
            if (condition.getAsBoolean()) {
                return;
            }
            Thread.sleep(100);
        }
        fail(failureMessage);
    }

    private void assertConditionRemainsTrue(BooleanSupplier condition,
                                            int durationSeconds,
                                            String failureMessage) throws InterruptedException {
        for (int i = 0; i < durationSeconds * 10; i++) {
            assertTrue(condition.getAsBoolean(), failureMessage);
            Thread.sleep(100);
        }
    }
}

