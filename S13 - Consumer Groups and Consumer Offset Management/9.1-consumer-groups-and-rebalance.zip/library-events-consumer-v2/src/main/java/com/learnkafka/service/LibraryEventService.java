package com.learnkafka.service;

import com.learnkafka.domain.LibraryEventDTO;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class LibraryEventService {

	private static final Logger log = LoggerFactory.getLogger(LibraryEventService.class);

	public void processEvent(ConsumerRecord<Integer, LibraryEventDTO> consumerRecord) {
		// Legacy manual deserialization (kept for reference):
		// try {
		// 	LibraryEventDTO libraryEventDTO = objectMapper.readValue(consumerRecord.value(), LibraryEventDTO.class);
		// 	log.info("Deserialized library event DTO: {}", libraryEventDTO);
		// } catch (JsonProcessingException e) {
		// 	throw new IllegalArgumentException("Failed to deserialize library event payload", e);
		// }

		LibraryEventDTO libraryEventDTO = consumerRecord.value();
		log.info("Deserialized library event DTO: {}", libraryEventDTO);
	}
}
