package com.learnjava.controller;

import com.learnjava.config.AppConstants;
import com.learnjava.domain.LibraryEvent;
import com.learnjava.domain.LibraryEventType;
import com.learnjava.service.LibraryEventService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(AppConstants.API_BASE_PATH)
public class LibraryEventsController {

    private final LibraryEventService libraryEventService;

    public LibraryEventsController(LibraryEventService libraryEventService) {
        this.libraryEventService = libraryEventService;
    }

    @PostMapping
    public ResponseEntity<LibraryEvent> createLibraryEvent(
            @RequestBody @Valid LibraryEvent libraryEvent) {

        if (libraryEvent.eventType() != LibraryEventType.ADD) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .build();
        }

        LibraryEvent created = libraryEventService.createLibraryEvent(libraryEvent);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(created);
    }
}

