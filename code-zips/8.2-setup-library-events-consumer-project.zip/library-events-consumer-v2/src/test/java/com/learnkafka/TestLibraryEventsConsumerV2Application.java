package com.learnkafka;

import org.springframework.boot.SpringApplication;

public class TestLibraryEventsConsumerV2Application {

	public static void main(String[] args) {
		SpringApplication.from(LibraryEventsConsumerV2Application::main).with(TestcontainersConfiguration.class).run(args);
	}

}
