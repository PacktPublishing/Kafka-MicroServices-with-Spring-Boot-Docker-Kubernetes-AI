package com.learnkafka.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learnkafka.domain.LibraryEventDTO;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.util.backoff.FixedBackOff;

@Configuration
@EnableKafka
public class LibraryEventsConsumerConfig {

	@Bean
	ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	@Bean
	ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO> kafkaListenerContainerFactory(
			ConsumerFactory<Integer, LibraryEventDTO> consumerFactory,
			DefaultErrorHandler defaultErrorHandler) {
		var factory = new ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO>();
		factory.setConsumerFactory(consumerFactory);
		factory.setCommonErrorHandler(defaultErrorHandler);
		//factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL); // Default ContainerProperties.AckMode.BATCH
//		factory.setConcurrency(3);  // ← 3 consumer threads
		return factory;
	}

	@Bean
	DefaultErrorHandler defaultErrorHandler() {
		return new DefaultErrorHandler(new FixedBackOff(1000L, 2L));
	}
}


