package com.learnkafka.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.learnkafka.domain.LibraryEventDTO;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.listener.RetryListener;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;

@Configuration
@EnableKafka
public class LibraryEventsConsumerConfig {

	private static final Logger log = LoggerFactory.getLogger(LibraryEventsConsumerConfig.class);

	@Bean
	ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	@Bean
	ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO> kafkaListenerContainerFactory(
			ConsumerFactory<Integer, LibraryEventDTO> consumerFactory,
			DefaultErrorHandler defaultErrorHandler) {
		var factory = new ConcurrentKafkaListenerContainerFactory<Integer, LibraryEventDTO>();
		factory.setConsumerFactory(consumerFactory);
		factory.setCommonErrorHandler(defaultErrorHandler);
		//factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL); // Default ContainerProperties.AckMode.BATCH
//		factory.setConcurrency(3);  // ← 3 consumer threads
		return factory;
	}

	@Bean
	DefaultErrorHandler defaultErrorHandler() {
		var exponentialBackOff = new ExponentialBackOffWithMaxRetries(2);
		exponentialBackOff.setInitialInterval(1000L);
		exponentialBackOff.setMultiplier(2.0);
		exponentialBackOff.setMaxInterval(4000L);

		var errorHandler = new DefaultErrorHandler(exponentialBackOff);

		// Previous lambda-based RetryListener (kept for reference):
		// errorHandler.setRetryListeners((record, ex, deliveryAttempt) -> {
		//     var message = String.format(
		//             "Retry attempt %d failed for topic=%s partition=%d offset=%d: %s",
		//             deliveryAttempt,
		//             record.topic(),
		//             record.partition(),
		//             record.offset(),
		//             ex.getMessage());
		//     log.warn(message, ex);
		// });

		RetryListener retryListener = new RetryListener() {
			@Override
			public void failedDelivery(ConsumerRecord<?, ?> record,
                                       Exception ex,
                                       int deliveryAttempt) {
				var message = String.format(
						"Retry attempt %d failed for topic=%s partition=%d offset=%d: %s",
						deliveryAttempt,
						record.topic(),
						record.partition(),
						record.offset(),
						ex.getMessage());
				log.warn(message, ex);
			}
		};
		errorHandler.addNotRetryableExceptions(
				IllegalArgumentException.class,        // bad payload — will never succeed
				NullPointerException.class,            // programming error
				DataIntegrityViolationException.class  // duplicate key — will always fail
		);
		errorHandler.setRetryListeners(retryListener);

		return errorHandler;
	}
}


